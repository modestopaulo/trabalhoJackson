const express = require('express');
const app = express();
const db = require('./app');

app.use(express.json()); // Permite que o Express leia JSON no corpo das requisições

// Importar e usar as rotas
const authRoutes = require('./routes/authRoutes.js');
const userRoutes = require('./routes/userRoutes');
// Outras rotas serão adicionadas aqui:
// const productRoutes = require('./routes/productRoutes');
// const categoryRoutes = require('./routes/categoryRoutes');
// const orderRoutes = require('./routes/odrderRoutes');


app.use('/api/auth', authRoutes); // Rotas de autenticação (login, registro)
app.use('/api/users', userRoutes); // Rotas de gerenciamento de usuários (perfil)
// app.use('/api/products', productRoutes);
// app.use('/api/categories', categoryRoutes);
// app.use('/api/orders', orderRoutes);


app.get('/', (req, res) => {
    res.send('API RESTful em Node.js com Sequelize');
});

// Adicionar um middleware de tratamento de erros básico (vamos aprimorar depois)
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).send('Algo deu errado!');
});

module.exports = app;

