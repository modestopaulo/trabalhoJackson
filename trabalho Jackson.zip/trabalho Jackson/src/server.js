require('dotenv').config();
const app = require('./app');
const db = require('./config/database'); // Importa o objeto db do config/database.js

const PORT = process.env.PORT || 3000;

db.sequelize.authenticate()
    .then(() => {
        console.log('Conexão com o banco de dados estabelecida com sucesso!');
        // Sincroniza todos os modelos com o banco de dados
        // CUIDADO: `alter: true` em produção pode ser perigoso, use migrations!
        return db.sequelize.sync({ alter: true }); // ou { force: true } para recriar as tabelas (apaga dados)
    })
    .then(() => {
        console.log('Modelos sincronizados com o banco de dados!');
        app.listen(PORT, () => {
            console.log(`Servidor rodando na porta ${PORT}`);
        });
    })
    .catch((error) => {
        console.error('Erro ao conectar ou sincronizar com o banco de dados:', error);
        process.exit(1); // Encerra o processo com erro
    });