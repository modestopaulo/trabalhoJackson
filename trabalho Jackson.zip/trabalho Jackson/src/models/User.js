module.exports = (sequelize, DataTypes) => {
    const User = sequelize.define('User', { // 'User' é o nome do modelo
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true,
            allowNull: false,
        },
        name: {
            type: DataTypes.STRING, // VARCHAR
            allowNull: false,
        },
        email: {
            type: DataTypes.STRING,
            allowNull: false,
            unique: true,
        },
        password: {
            type: DataTypes.STRING, // Armazenará o hash
            allowNull: false,
        },
    }, {
        tableName: 'users', // Nome da tabela no banco de dados (por padrão seria 'users')
    });

    User.associate = (models) => {
        // Um usuário pode ter muitos pedidos (One-to-Many)
        User.hasMany(models.Order, {
            foreignKey: 'userId', // Nome da coluna de chave estrangeira em Order
            as: 'orders', // Alias para o relacionamento
        });
    };

    return User;
};