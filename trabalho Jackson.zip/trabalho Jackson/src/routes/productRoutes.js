const express = require('express');
const router = express.Router();

// Exemplo de rota GET para produtos
router.get('/', (req, res) => {
    res.json({ message: 'Lista de produtos' });
});

module.exports = router;